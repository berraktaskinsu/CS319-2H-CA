package settlers;

import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.input.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class HowToPlayView extends View{

	ScrollPane scrollPane;
	HBox everything;
	Image background;
	ImageView mv;
	BackButton backButton;
	Text text;
	Label label;
	VBox paneComponents;
	
	public HowToPlayView(HowToPlayController howToPlayController) {
		
		super(howToPlayController);
		backButton = new BackButton();
		backButton.setOnMouseClicked( new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				goToMainMenu();
			}
			
		});
		
		label = new Label("How To Play?");
		label.setFont(Font.font("Cambria",FontWeight.BOLD, FontPosture.REGULAR, 50));
		label.setTextFill(Color.DARKGOLDENROD);
		
		text = new Text("\tComponents\n" + 
				"�	19 terrain hexes (tiles)\n" + 
				"�	6 sea frame pieces\n" + 
				"�	95 Resource Cards\n" + 
				"�	25 Development Cards (14 Knight/Soldier Cards\n" + 
				"�	6 Progress Cards, 5 Victory Point Cards)\n" + 
				"�	16 cities (4 of each color shaped like churches)\n" + 
				"�	20 settlements\n" + 
				"�	60 roads (15 of each color shaped like bars)\n" + 
				"�	2 dice \n" + 
				"�	1 robber\n" + 
				"\n" + 
				"Starting\n" + 
				"1.	Select a color and enter name\n" + 
				"2.	Roll dice to decide turns\n" + 
				"3.	Place your 2 roads and your 2 settlements on the game board.\n" + 
				"4.	You receive resources for each terrain hex around your second starting settlement.\n" + 
				"5.	Important: Settlements and cities may only be placed at the corners of the terrain hexes-never along the edges. Roads may only be placed at the edges of the terrain hexes-1 road per edge.\n" + 
				"\n" + 
				"Game Play\n" + 
				"On your turn, you can do the following in the order listed:\n" + 
				"�	You must roll for resource production (the result applies to all players).\n" + 
				"�	You may trade resources with other players or using maritime trade.\n" + 
				"�	You may build roads, settlements or cities and/or buy Development Cards. You may also play one Development Card at any time during your turn.\n" + 
				"�	After you're done, end turn. \n" + 
				"\n" + 
				"\n" + 
				"Game Turn\n" + 
				"I. Resource Production\n" + 
				"�	You begin your turn by rolling both dice.\n" + 
				"�	The sum of the dice determines which terrain hexes produce resources.\n" + 
				"�	Each player who has a settlement on an intersection that borders a terrain hex marked with the number rolled receives 1 Resource Card of the hex's type.\n" + 
				"�	If you have 2 or 3 settlements bordering that hex, you receive 1 Resource Card for each settlement.\n" + 
				"�	You receive 2 Resource Cards for each city you own that borders that hex.\n" + 
				"�	If there is not enough of a given resource in the supply to fulfill everyone's production, then no one receives any of that resource during that turn.\n" + 
				"II. Trade\n" + 
				"Afterwards you may trade freely (using either or both types of trades below) to gain needed Resource Cards:\n" + 
				"�	A. Domestic Trade\n" + 
				"On your turn, you can trade Resource Cards with any of the other players or NPCs. You can select which resources you need and what you are willing to trade for them. The other players can also make their own proposals and counter offers.\n" + 
				"B. Maritime Trade\n" + 
				"You can also trade without the other players! During your turn, you can always trade at 4:1 by putting 4 identical Resource Cards back in their stack and taking any 1 Resource Card of your choice for it. If you have a settlement or city on a harbor, you can trade with the bank more favorably: at either a 3:1 ratio or in special harbors (trading the resource type shown) at 2:1.\n" + 
				"(Important: The 4:1 trade is always possible, even if you do not have a settlement on a harbor).\n" + 
				"III. Build\n" + 
				"Now you can build. Through building, you can increase your victory points, expand your road network, improve your resource production, and/or buy useful Development Cards.\n" + 
				"To build, you must pay specific combinations of Resource Cards \n" + 
				"You cannot build more pieces than what is available in your pool-a maximum of 5 settlements, 4 cities, and 15 roads.\n" + 
				"A. Road Requires: Brick & Lumber\n" + 
				"�	A new road must always connect to one of your existing roads, settlements, or cities.\n" + 
				"�	Only 1 road can be built on any given path.\n" + 
				"�	The first player to build a continuous road (not counting forks) of at least 5 road segments, receives the Special Card \"Longest Road\".\n" + 
				"�	If another player succeeds in building a longer road than the one created by the current owner of the \"Longest Road\" card, he immediately takes the Special Card (and its 2 victory points). \n" + 
				"B. Settlement Requires: Brick, Lumber, Wool, & Grain\n" + 
				"�	Take special note of the \"Distance Rule\": you may only build a settlement at an intersection if all 3 of the adjacent intersections are vacant.\n" + 
				"�	Each of your settlements must connect to at least 1 of your own roads.\n" + 
				"�	Regardless of whose turn it is, when a terrain hex produces resources, you receive 1 Resource Card for each settlement you have adjacent to that terrain hex.\n" + 
				"�	Each settlement is worth 1 victory point.\n" + 
				"C. City Requires: 3 Ore & 2 Grain\n" + 
				"�	You may only establish a city by upgrading one of your settlements.\n" + 
				"�	When you upgrade a settlement to a city, put the settlement (house) piece back in your supply and replace it with a city piece (church).\n" + 
				"�	Cities produce twice as many resources as settlements.\n" + 
				"�	You acquire 2 Resource Cards for an adjacent terrain hex that produces resources.\n" + 
				"�	Each city is worth 2 victory points.\n" + 
				"D. Buying Development Card (requires: Ore, Wool, & Grain)\n" + 
				"�	There are 3 different kinds of these cards: Knight; Progress; and Victory Point. Each has a different effect.\n" + 
				"�	You cannot buy Development Cards if the supply is empty.\n" + 
				"\n" + 
				"IV. Special Cases\n" + 
				"A. Rolling a \"7\" and Activating the Robber\n" + 
				"�	If you roll a \"7\", no one receives any resources.\n" + 
				"�	Instead, every player who has more than 7 Resource Cards must select half (rounded down) of his Resource Cards and return them to the bank.\n" + 
				"�	Then you must move the robber. Proceed as follows:\n" + 
				"1.	You must move the robber immediately to the number token of any other terrain hex or to the desert hex.\n" + 
				"2.	Then you steal 1 (random) Resource Card from an opponent who has a settlement or city adjacent to the target terrain hex. You then take 1 at random.\n" + 
				"\n" + 
				"If the target hex is adjacent to 2 or more players' settlements or cities, you choose which one you want to rob.\n" + 
				"Important: If the production number for the hex containing the robber is rolled, the owners of adjacent settlements and cities do not receive resources. The robber prevents it.\n" + 
				"\n" + 
				"\n" + 
				"B. Playing Development Cards\n" + 
				"At any time during your turn after rolling dice, you may play 1 Development Card (on the table). That card, however, may not be a card you bought during the same turn!\n" + 
				"�	Knight Cards \n" + 
				"\n" + 
				"o	If you play a Knight Card, you must immediately move the robber. See \"Rolling a \"7\" and Activating the Robber\" above and follow steps 1 and 2.\n" + 
				"o	The first player to have played 3 Knight Cards receives the Special Card \"Largest Army\", which is worth 2 victory points.\n" + 
				"o	If another player has played more Knight Cards than the current holder of the Largest Army card, he immediately takes the Special Card and its 2 victory points.\n" + 
				"�	Victory Point Cards\n" + 
				"o	Adds victory points to the total score of the player.\n" + 
				"o	Victory Point cards are kept hidden till the end of the game.\n" + 
				"o	You may play any number of Victory Point Cards during your turn, even during the turn you purchase them.\n" + 
				"End of the Game\n" + 
				"If you have 10 or more victory points during your turn the game ends and you are the winner! If you reach 10 points when it is not your turn, the game continues until any player (including you) has 10 points on his turn.\n" + 
				"");
		text.setFont(Font.font("Cambria",FontWeight.NORMAL, FontPosture.REGULAR, 12));
		
		paneComponents = new VBox();
		paneComponents.getChildren().addAll(label, text);
		paneComponents.setSpacing(10);
		paneComponents.setPadding(new Insets(50, 0, 0, 80));
		

		
		ScrollPane pane = new ScrollPane();
		//pane.getStyleClass().add("scroll-pane");
		pane.getStylesheets().add("settlers.css");
		
		pane.setFocusTraversable(false);
		pane.setPrefSize(800, Program.HEIGHT);
		pane.setTranslateX(200);
		pane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.NEVER);
		pane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.ALWAYS);
		pane.setStyle("-fx-background-color: transparent");
		pane.setContent(paneComponents);
		
		everything = new HBox();
		everything.getChildren().addAll(backButton, pane);

		background = new Image("img3.jpg");
		if (Program.MODE == "pirates") {
			background = new Image("pirate2.jpg");
		}
		
		mv = new ImageView(background);
		mv.setFitWidth(Program.WIDTH);
		mv.setFitHeight(Program.HEIGHT);
		getChildren().addAll(mv, everything);

	}

}