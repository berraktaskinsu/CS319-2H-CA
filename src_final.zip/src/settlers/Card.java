package settlers;

public interface Card {

	public void setType(String type);
	public String getType();
	public int getCardId();
	public void setCardId(int cardId);
	public void setGeneralType(String type);
	public String getGeneralType();
	
}
