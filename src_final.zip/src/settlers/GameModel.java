package settlers;

import java.util.ArrayList;

import javafx.scene.paint.Color;

public class GameModel {

	private int numberOfPlayers;
	private Player[] players;
	private Bank bank;
	private Board board;
	private int playerInTurn;
	
	
	public GameModel(PlayerProperty[] playerProperties) {
		
		this.setNumberOfPlayers(playerProperties.length);
		players = new Player[getNumberOfPlayers()];
		 
		for (int i = 0 ; i < getNumberOfPlayers() ; i++) {
			PlayerProperty playerProperty = playerProperties[i];
			Player player = new Player(playerProperty.getName(), playerProperty.getIcon(), playerProperty.getColor());
			players[i] = player;
			/*for (int j = 0 ; j < 18 ; j++) {
				Player player = new Player(playerProperty.getName(), playerProperty.getIcon(), playerProperty.getColor());
				players[i] = player;
			}*/
		}
		createBank();
		setPlayerInTurn(1);
		
	}
	
	public void createBoard(Hex[] hexes, Path[] paths, Corner[] corners) {
		setBoard(new Board(hexes, paths, corners));
	}
	
	public void createBank() {
		setBank(new Bank());
	}
	
	public Player[] getPlayers() {
		return players;
	}
	
	public void setPlayers(Player[] players) {
		this.players = players;
	}

	public int getNumberOfPlayers() {
		return numberOfPlayers;
	}

	public void setNumberOfPlayers(int numberOfPlayers) {
		this.numberOfPlayers = numberOfPlayers;
	}

	public int getPlayerInTurn() {
		return playerInTurn;
	}

	public void setPlayerInTurn(int playerInTurn) {
		this.playerInTurn = playerInTurn;
	}
	
	public int nextTurn(int cycle) {
		if (cycle == 1) {
			if (getPlayerInTurn() < 4) {
				setPlayerInTurn(getPlayerInTurn() + 1);
			} else if (getPlayerInTurn() == 4) {
				return cycle + 1;
			}
		} else if (cycle == 2) {
			if (getPlayerInTurn() > 1) {
				setPlayerInTurn(getPlayerInTurn() - 1);
			} else if (getPlayerInTurn() == 1) {
				return cycle + 1;
			}
		} else {
			if (getPlayerInTurn() == 4) {
				setPlayerInTurn(1);
			} else {
				setPlayerInTurn(getPlayerInTurn() + 1);
			}
		}
		return cycle;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public Board getBoard() {
		return board;
	}

	public void setBoard(Board board) {
		this.board = board;
	}
	
	public ArrayList<Card> determineFirstCards(int cornerId) {
		ArrayList<String> cards = board.determineFirstCards(cornerId);
		ArrayList<Card> realCards = new ArrayList<Card>();
		for (int i = 0 ; i < cards.size() ; i++) {
			ResourceCard realCard;
			if (cards.get(i) == "lumber") {
				realCard = bank.giveLumberCard();
				realCards.add(realCard);
			} else if (cards.get(i) == "wool") {
				realCard = bank.giveWoolCard();
				realCards.add(realCard);
			} else if (cards.get(i) == "grain") {
				realCard = bank.giveGrainCard();
				realCards.add(realCard);
			} else if (cards.get(i) == "brick") {
				realCard = bank.giveBrickCard();
				realCards.add(realCard);
			} else if (cards.get(i) == "ore"){
				realCard = bank.giveOreCard();
				realCards.add(realCard);
			}
			// nothing if "null"
		}
		players[playerInTurn - 1].takeCards(realCards);
		return realCards;
	}
	
	public void distributeResourcesFromHexes(ArrayList<Hex> hexes) {
		for (int i = 0 ; i < hexes.size(); i++) {
			distributeResourcesFromHex(hexes.get(i));
		}
	}
	
	public void distributeResourcesFromHex(Hex hex) {
		String hexType = hex.getType();
		String cardType = "";
		if (hexType == "Mountains") {
			cardType = "ore";
		} else if (hexType == "Fields") {
			cardType = "grain";
		} else if (hexType == "Pasture") {
			cardType = "wool";
		} else if (hexType == "Forest") {
			cardType = "lumber";
		} else if (hexType == "Hills") {
			cardType = "brick";
		}
		
		int[] hexCorners = hex.getCorners();
		Corner[] corners = board.getCorners();
		ArrayList<Color> colors = new ArrayList<Color>();
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		
		for (int i = 0 ; i < hexCorners.length ; i++) {
			Corner corner = corners[hexCorners[i]];
			if (corner.getOccupied() == 1 || corner.getOccupied() == 2) {
				Color color = corner.getColor();
				int number = corner.getOccupied();
				colors.add(color);
				numbers.add(number);
			}
		}
		giveResourcesByColors(cardType, numbers, colors);
	}
	
	public void giveResourcesByColors(String cardType, ArrayList<Integer> numbers, ArrayList<Color> colors) {
		
		for (int i = 0 ; i < colors.size() ; i++) {
			giveResourcesByColor(cardType, numbers.get(i), colors.get(i));
		}
	}
	
	public void giveResourcesByColor(String cardType, int number, Color color) {
		
		for (int i = 0 ; i < players.length ; i++) {
			if (players[i].getColor() == color) {
				for (int j = 0 ; j < number ; j++) {
					Card card = bank.giveResourceCard(cardType);
					players[i].takeCard(card);
				}
			}
		}
	
	}
	
	
}
