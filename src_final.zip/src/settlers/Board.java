package settlers;

import java.util.ArrayList;

import javafx.scene.paint.Color;

public class Board {
	
	private Hex[] hexes;
	private Path[] paths;
	private Corner[] corners;
	
	public Board(Hex[] hexes, Path[] paths, Corner[] corners) {
		setHexes(hexes);
		setPaths(paths);
		setCorners(corners);
	}

	public Hex[] getHexes() {
		return hexes;
	}

	public void setHexes(Hex[] hexes) {
		this.hexes = hexes;
	}

	public Path[] getPaths() {
		return paths;
	}

	public void setPaths(Path[] paths) {
		this.paths = paths;
	}

	public Corner[] getCorners() {
		return corners;
	}

	public void setCorners(Corner[] corners) {
		this.corners = corners;
	}
	
	public boolean place(int flag, int id, Color color, boolean firstTurn) {
		
		if (flag == 0 && checkIfPathPlacable(id, color, firstTurn)) {
			paths[id - 1].setOccupied(true);
			paths[id - 1].setColor(color);
			return true;
			
		} else if (flag == 1 && checkIfSettlementPlacable(id, color, firstTurn)) {
			corners[id - 1].setOccupied(1);
			corners[id - 1].setColor(color);
			return true;
		} else if (flag == 2 && checkIfCityPlacable(id, color)) {
			corners[id - 1].setOccupied(2);
			return true;
		}
		return false;
	}
	
	public boolean checkIfPathPlacable(int id, Color color, boolean firstTurn) {
		
		if (firstTurn) {
			Path path = paths[id -1];
			if (!path.isOccupied()) {
				int[] neighbourCorners = path.getNeighbourCorners();
				boolean flag = false;
				for (int i = 0 ; i < neighbourCorners.length ; i++) {
					Corner corner = corners[neighbourCorners[i]];
					
					if (corner.getOccupied() != 0 && corner.getColor() == color) {
						flag = true;
						int[] neighbourPaths = corner.getNeighbourPaths();
						for (int j = 0 ; (j < neighbourPaths.length) && (neighbourPaths[j] != id - 1) ; j++) {
							if (neighbourPaths[j] != -1) {
								Path neighbourPath = paths[neighbourPaths[j]];
								if (neighbourPath.isOccupied() && neighbourPath.getColor() == color) {
									return false;
								}
							}
						}	
					}
					
				}
				return flag;
			}
		} else {
			Path path = paths[id -1];
			if (!path.isOccupied()) {
				int[] neighbourCorners = path.getNeighbourCorners();
				for (int i = 0 ; i < neighbourCorners.length ; i++) {
					Corner corner = corners[neighbourCorners[i]];
					if (corner.getOccupied() != 0 && corner.getColor() == color) {
						return true;
					}
					int[] neighbourPaths = corner.getNeighbourPaths();
					for (int j = 0 ; (j < neighbourPaths.length) && (neighbourPaths[j] != id - 1) ; j++) {
						if (neighbourPaths[j] != -1) {
							Path neighbourPath = paths[neighbourPaths[j]];
							if (neighbourPath.isOccupied() && neighbourPath.getColor() == color) {
								return true;
							}
						}
					}
				}
			}
		}

		return false;
		
		
	}
	
	public boolean checkIfSettlementPlacable(int id, Color color, boolean firstTurn) {
		
		//
		
		if (firstTurn) {
			Corner corner = corners[id - 1];
			if (corner.getOccupied() == 0) {
				int[] neighbourPaths = corner.getNeighbourPaths();
				for (int i = 0 ; (i < neighbourPaths.length) && (neighbourPaths[i] != -1) ; i++) {
					Path path = paths[neighbourPaths[i]];
					int[] neighbourCorners = path.getNeighbourCorners();
					for (int j = 0 ; j < neighbourCorners.length ; j++) {
						Corner neighbourCorner = corners[neighbourCorners[j]];
						if (neighbourCorner.getOccupied() != 0) {
							return false;
						}
					}
				}
			}
		} else {
			boolean connected = false;
			Corner corner = corners[id - 1];
			if (corner.getOccupied() == 0) {
				int[] neighbourPaths = corner.getNeighbourPaths();
				for (int i = 0 ; (i < neighbourPaths.length) && (neighbourPaths[i] != -1) ; i++) {
					Path path = paths[neighbourPaths[i]];
					if (path.isOccupied() && path.getColor() == color) {
						connected = true;
					}
					int[] neighbourCorners = path.getNeighbourCorners();
					for (int j = 0 ; j < neighbourCorners.length ; j++) {
						Corner neighbourCorner = corners[neighbourCorners[j]];
						if (neighbourCorner.getOccupied() != 0) {
							return false;
						}
					}
				}
				if (!connected) {
					return false;
				}
			}
		}
		return true;
		
	}
	
	public boolean checkIfCityPlacable(int id, Color color) {
		
		Corner corner = corners[id - 1];
		if (corner.getOccupied() == 1) {
			return true;
		}
		return false;
		
	}
	
	public ArrayList<String> determineFirstCards(int cornerId) {
		ArrayList<String> cards = new ArrayList<String>();
		Corner corner = corners[cornerId - 1];
		int[] containingHexes = corner.getContainingHexes();
		for (int i = 0 ; (i < containingHexes.length); i++) {
			if (containingHexes[i] != -1) {
				Hex hex = hexes[containingHexes[i]];
				String type;
				if (hex.getType() == "Mountains") {
					type = "ore";
				} else if (hex.getType() == "Hills") {
					type = "brick";
				} else if (hex.getType() == "Forest") {
					type = "lumber";
				} else if (hex.getType() == "Pasture") {
					type = "wool";
				} else if (hex.getType() == "Fields") {
					type = "grain";
				} else {
					type = "null";
				}
				System.out.println(type);
				cards.add(type);
			}
		}
		return cards;
	}
	
	public ArrayList<Hex> findHexByToken(int token) {
		ArrayList<Hex> tokens = new ArrayList<Hex>();
		for (int i = 0 ; i < hexes.length ; i++) {
			if (hexes[i].getToken() == token) {
				tokens.add(hexes[i]);
			}
		}
		return tokens;
		
		/*ArrayList<Corner> returned = new ArrayList<Corner>();
		
		for (int i = 0 ; i < tokens.size(); i++) {
			int[] hexCorners = tokens.get(i).getCorners();
			for (int j = 0 ; j < hexCorners.length ; j++) {
				Corner corner = corners[hexCorners[i]];
				returned.add(corner);
			}
		}*/
	}
	
}
