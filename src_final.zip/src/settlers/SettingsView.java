package settlers;

import java.io.File;
import javafx.scene.control.ComboBox;
import java.io.IOException;
import javafx.collections.FXCollections;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.input.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
// LANGUAGE 

public class SettingsView extends View{

	MenuButton menuButton;
	MenuItem item1;
	MenuItem item2;
	MenuItem item3;
	Label language;
	Label colorBlindnessMode;
	Label volume;
	Label vpointsLabel;
	BackButton backButton;
	HBox selection1;
	HBox selection2;
	HBox selection3;
	HBox selection4;
	HBox everything;
	Pane pane;
	CheckBox checkBox;
	Slider slider;
	VBox selections;
	Image background;
	ImageView mv;
	Label modeLabel;
	
	
	public SettingsView(SettingsController settingsController) {
		
		super(settingsController);
		
		
		background = new Image("img2.jpg");
		if (Program.MODE == "pirates") {
			background = new Image("pirate1.jpg");
		}
		
		Button prevButton = new Button();
		prevButton.getStyleClass().add("previous-button");
		prevButton.setBackground(new Background(new BackgroundFill(Color.RED, new CornerRadii(0), new Insets(0,0,0,0))));
		
		Button nextButton = new Button();
		nextButton.getStyleClass().add("next-button");
		nextButton.setBackground(new Background(new BackgroundFill(Color.RED, new CornerRadii(0), new Insets(0,0,0,0))));
		
		modeLabel = new Label("Normal Game");
		modeLabel.setFont(Font.font("Cambria",FontWeight.BOLD, FontPosture.REGULAR, 30));
		modeLabel.setTextFill(Color.WHITE);
		selection2 = new HBox();
		selection2.getChildren().addAll(prevButton, modeLabel, nextButton);
		selection2.setSpacing(50);
		
		slider = new Slider(0, 100, 0);
		volume = new Label("Volume:");
		volume.setFont(Font.font("Cambria",FontWeight.BOLD, FontPosture.REGULAR, 30));
		volume.setTextFill(Color.WHITE);
		selection3 = new HBox();
		selection3.getChildren().addAll(volume, slider);
		selection3.setSpacing(20);
		
		//victoryPointSelection
		vpointsLabel = new Label("Goal Score:");
		vpointsLabel.setFont(Font.font("Cambria",FontWeight.BOLD, FontPosture.REGULAR, 30));
		vpointsLabel.setTextFill(Color.WHITE);
		String victoryPoints[] = { "10", "11", "12", "13", "14" }; 
		ComboBox<String> combobox2 = new ComboBox(FXCollections.observableArrayList(victoryPoints)); 
		combobox2.getSelectionModel().selectFirst();
		selection4 = new HBox();
		selection4.getChildren().addAll(vpointsLabel,combobox2);
		selection4.setSpacing(50);
		
		
		
		prevButton.setVisible(false);
		nextButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				prevButton.setVisible(true);
				nextButton.setVisible(false);
				Program.MODE = "pirates";
				modeLabel.setText("Pirates of Catan");
				mv.setImage(new Image("pirate1.jpg"));
			}
		});
		
		prevButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				prevButton.setVisible(false);
				nextButton.setVisible(true);
				Program.MODE = "normal";
				modeLabel.setText("Normal Game");
				mv.setImage(new Image("img2.jpg"));
				
			}
		});
		
		selections = new VBox();
		selections.getChildren().addAll(selection2, selection3,selection4);
		selections.setSpacing(100);
		selections.setPadding(new Insets(100, 0, 0, 100));
		
		backButton = new BackButton();
		backButton.setOnMouseClicked( new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				goToMainMenu();
			}
			
		});
		
		pane = new Pane();
		pane.getChildren().addAll(selections);
		pane.setStyle("-fx-background-color: rgba(58, 51, 49, 0.5);");
		pane.setPrefSize(500, 500);
		pane.setTranslateY(200);
		pane.setTranslateX(390);
		
		everything = new HBox();
		everything.getChildren().addAll(backButton, pane);
		
		
		mv = new ImageView(background);
		mv.setFitWidth(Program.WIDTH);
		mv.setFitHeight(Program.HEIGHT);
		this.getChildren().addAll(mv,everything);
		
		
	}

}
