package settlers;

import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Screen;

public class TradePane extends Pane {
	
	
	Pane pane1, pane2;
	HBox exchangables1, exchangables2;
	HBox[] buttons1, buttons2;
	VBox[] cards1, cards2;
	StackPane[] stacks1, stacks2;
	Circle[] circles1, circles2;
	Text[] numbers1, numbers2;
	ImageView[] views1, views2;
	SettlersButton[] minus1, minus2, plus1, plus2;

	public TradePane() {
		
		setStyle("-fx-background-color: rgba(58, 51, 49, 0.5);");
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		setPrefSize(primaryScreenBounds.getWidth()/2 + 10,primaryScreenBounds.getHeight());
		
		setVisible(false);
		
		HBox exchangables1 = new HBox();
		HBox exchangables2 = new HBox();
		cards1 = new VBox[6];
		cards2 = new VBox[6];
		stacks1 = new StackPane[6];
		stacks2 = new StackPane[6];
		circles1 = new Circle[6];
		circles2 = new Circle[6];
		numbers1 = new Text[6];
		numbers2 = new Text[6];
		views1 = new ImageView[6];
		views2 = new ImageView[6];
		buttons1 = new HBox[6];
		buttons2 = new HBox[6];
		plus1 = new SettlersButton[6];
		plus2 = new SettlersButton[6];
		minus1 = new SettlersButton[6];
		minus2 = new SettlersButton[6];
		buttons1 = new HBox[6];
		buttons2 = new HBox[6];
		
		for (int i = 0 ; i < 6 ; i++) {
			final int j = i;
			numbers1[i] = new Text("0");
			numbers1[i].setLayoutX(25);
			numbers1[i].setLayoutY(47);
			numbers1[i].setFont(new Font("Cambria", 20));
			numbers1[i].setFill(Color.WHITE);
			numbers2[i] = new Text("0");
			numbers2[i].setLayoutX(25);
			numbers2[i].setLayoutY(47);
			numbers2[i].setFont(new Font("Cambria", 20));
			numbers2[i].setFill(Color.WHITE);
			circles1[i] = new Circle();
			circles1[i].setRadius(20);
			circles1[i].setLayoutX(25);
			circles1[i].setLayoutY(47);
			circles1[i].setOpacity(0.3);
			circles2[i] = new Circle();
			circles2[i].setRadius(20);
			circles2[i].setLayoutX(25);
			circles2[i].setLayoutY(47);
			circles2[i].setOpacity(0.3);
			
			if (i == 0) {
				views1[i] = new ImageView(new Image("lumber_card.jpg"));
				views2[i] = new ImageView(new Image("lumber_card.jpg"));
			} else if (i == 1) {
				views1[i] = new ImageView(new Image("ore_card.jpg"));
				views2[i] = new ImageView(new Image("ore_card.jpg"));
			} else if (i == 2) {
				views1[i] = new ImageView(new Image("sheep_card.jpg"));
				views2[i] = new ImageView(new Image("sheep_card.jpg"));
			} else if (i == 3) {
				views1[i] = new ImageView(new Image("wheat_card.jpg"));
				views2[i] = new ImageView(new Image("wheat_card.jpg"));
			} else if (i == 4) {
				views1[i] = new ImageView(new Image("brick_card.jpg"));
				views2[i] = new ImageView(new Image("brick_card.jpg"));
			} else {
				views1[i] = new ImageView(new Image("dev_card.jpeg"));
				views2[i] = new ImageView(new Image("dev_card.jpeg"));
			} 
			stacks1[i] = new StackPane();
			stacks1[i].setPrefSize(90, 135);
			views1[i].setFitHeight(135);
			views1[i].setFitWidth(90);
			views2[i].setFitHeight(135);
			views2[i].setFitWidth(90);
			stacks1[i].setOnMouseEntered(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					circles1[j].setOpacity(0.8);
				}
			});
			stacks1[i].setOnMouseExited(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					circles1[j].setOpacity(0.3);
				}
			});
			stacks1[i].getChildren().addAll(views1[i], circles1[i], numbers1[i]);
			stacks2[i] = new StackPane();
			stacks2[i].setPrefSize(90, 135);
			stacks2[i].setOnMouseEntered(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					circles2[j].setOpacity(0.8);
				}
			});
			stacks2[i].setOnMouseExited(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					circles2[j].setOpacity(0.3);
				}
			});
			stacks2[i].getChildren().addAll(views2[i], circles2[i], numbers2[i]);
			
			plus1[i] = new SettlersButton("+", 20, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
			plus1[i].setTextFill(Color.WHITE);
			plus1[i].setPrefHeight(20);
			plus1[i].setFont(new Font("Cambria", 15));
			
			plus1[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					numbers1[j].setText("" + (Integer.parseInt(numbers1[j].getText()) + 1));
				}
			});
			
			plus2[i] = new SettlersButton("+", 20, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
			plus2[i].setTextFill(Color.WHITE);
			plus2[i].setPrefHeight(20);
			plus2[i].setFont(new Font("Cambria", 15));
			
			plus2[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					numbers2[j].setText("" + (Integer.parseInt(numbers2[j].getText()) + 1));
				}
			});
			
			minus1[i] = new SettlersButton("-", 20, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
			minus1[i].setTextFill(Color.WHITE);
			minus1[i].setPrefHeight(20);
			minus1[i].setFont(new Font("Cambria", 15));
			
			minus1[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					if (numbers1[j].getText() != "0") {
						numbers1[j].setText("" + (Integer.parseInt(numbers1[j].getText()) - 1));
					}
				}
			});
			
			minus2[i] = new SettlersButton("-", 20, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
			minus2[i].setPrefHeight(20);
			minus2[i].setTextFill(Color.WHITE);
			minus2[i].setFont(new Font("Cambria", 15));
			
			minus2[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					if (numbers2[j].getText() != "0") {
						numbers2[j].setText("" + (Integer.parseInt(numbers2[j].getText()) - 1));
					}
				}
			});
			
			buttons1[i] = new HBox();
			buttons1[i].setSpacing(20);
			buttons1[i].getChildren().addAll(minus1[i], plus1[i]);
			buttons2[i] = new HBox();
			buttons2[i].setSpacing(20);
			buttons2[i].getChildren().addAll(minus2[i], plus2[i]);
			
			cards1[i] = new VBox();
			cards1[i].setSpacing(20);
			cards1[i].getChildren().addAll(stacks1[i], buttons1[i]);
			cards2[i] = new VBox();
			cards2[i].setSpacing(20);
			cards2[i].getChildren().addAll(stacks2[i], buttons2[i]);
			exchangables1.setSpacing(10);
			exchangables1.getChildren().add(cards1[i]);
			exchangables1.setTranslateX(50);
			exchangables2.setSpacing(10);
			exchangables2.getChildren().add(cards2[i]);
			exchangables2.setTranslateX(50);
		}
		
		HBox h1 = new HBox();
		HBox h2 = new HBox();
		SettlersButton confirm1 = new SettlersButton("Confirm", 150, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
		SettlersButton confirm2 = new SettlersButton("Confirm", 120, "-fx-background-color: rgba(139, 0, 0, 0.55);", "-fx-background-color: rgba(42, 62, 30, 0.55)");
		confirm1.setTextFill(Color.WHITE);
		confirm2.setTextFill(Color.WHITE);

		
		VBox everything = new VBox();
		everything.setTranslateY(50);
		everything.setSpacing(50);
		PlayerButton player1 = new PlayerButton(new ImageView(new Image("user0.png")), "", Color.WHITE, true);
		PlayerButton player2 = new PlayerButton(new ImageView(new Image("user0.png")), "", Color.WHITE, true);
		h1.getChildren().addAll(player1, confirm1);
		h1.setSpacing(100);
		h2.setSpacing(100);
		h1.setTranslateX(50);
		h2.setTranslateX(50);
		h2.getChildren().addAll(player2, confirm2);
		
		everything.getChildren().addAll(h1, exchangables1, exchangables2, h2);
		SettlersButton closeButton = new SettlersButton("Close", 120, "-fx-background-color: rgba(225, 225, 225, 0.55);", "-fx-background-color: rgba(225, 225, 225, 0.8);");
		closeButton.setTranslateX(20);
		closeButton.setTranslateY(20);
		closeButton.setTextFill(Color.WHITE);
		closeButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				for (int i = 0 ; i < 6 ; i++) {
					numbers1[i].setText("0");
					numbers2[i].setText("0");
				}
				confirm1.setDisable(false);
				confirm2.setDisable(false);
				setVisible(false);
			}
		});
		
		getChildren().addAll(everything, closeButton);
		
		
		
	}
	
	public void setVisible(boolean flag, int type) {
		if (type == 1) { // player
			
		} else { // bank
			
		}
		setVisible(flag);
	}
	
	
}
