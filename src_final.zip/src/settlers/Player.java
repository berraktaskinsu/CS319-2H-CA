package settlers;


import java.util.ArrayList;

import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

public class Player {

	private ImageView icon;
	private String name;
	private Color color;
	private int numberOfRoads;
	private int numberOfSettlements;
	private int numberOfCities;
	
	private ArrayList<Card> hand;
	private ArrayList<DevelopmentCard> front; // knight
	private boolean strongestArmy;
	private boolean longestRoad;
	private int numberOfCards;
	
	public Player(String playerName, ImageView icon, Color color) {
		hand = new ArrayList<Card>();
		setName(playerName);
		setIcon(icon);
		setColor(color);
		setNumberOfRoads(15);
		setNumberOfSettlements(5);
		setNumberOfCities(4);
		setNumberOfCards(0);
		setStrongestArmy(false);
		setLongestRoad(false);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ImageView getIcon() {
		return icon;
	}

	public void setIcon(ImageView icon) {
		this.icon = icon;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public int getNumberOfRoads() {
		return numberOfRoads;
	}

	public void setNumberOfRoads(int numberOfRoads) {
		this.numberOfRoads = numberOfRoads;
	}

	public int getNumberOfSettlements() {
		return numberOfSettlements;
	}

	public void setNumberOfSettlements(int numberOfSettlements) {
		this.numberOfSettlements = numberOfSettlements;
	}

	public int getNumberOfCities() {
		return numberOfCities;
	}

	public void setNumberOfCities(int numberOfCities) {
		this.numberOfCities = numberOfCities;
	}

	public ArrayList<Card> getHand() {
		return hand;
	}

	public void setHand(ArrayList<Card> hand) {
		this.hand = hand;
	}

	public ArrayList<DevelopmentCard> getFront() {
		return front;
	}

	public void setFront(ArrayList<DevelopmentCard> front) {
		this.front = front;
	}

	public int getNumberOfCards() {
		return numberOfCards;
	}

	public void setNumberOfCards(int numberOfCards) {
		this.numberOfCards = numberOfCards;
	}

	public boolean hasStrongestArmy() {
		return strongestArmy;
	}

	public void setStrongestArmy(boolean strongestArmy) {
		this.strongestArmy = strongestArmy;
	}

	public boolean hasLongestRoad() {
		return longestRoad;
	}

	public void setLongestRoad(boolean longestRoad) {
		this.longestRoad = longestRoad;
	}
	
	public void takeCard(Card card) {
		hand.add(card);
		numberOfCards++;
	}
	
	public Card giveCard(int cardId) {
		for (int i = 0 ; i < hand.size(); i++) {
			if (hand.get(i).getCardId() == cardId) {
				numberOfCards--;
				return hand.get(i);
			}
		}
		return null;
	}
	
	public void takeCards(ArrayList<Card> cards) {
		for (int i = 0 ; i < cards.size() ; i++) {
			takeCard(cards.get(i));
		}
	}
	
	public Card[] giveCards(int[] cardIds) {
		Card[] cards = new Card[cardIds.length];
		for (int i = 0 ; i < cardIds.length ; i++) {
			cards[i] = giveCard(cardIds[i]);
		}
		return cards;
	}
	public int getNumberOfWoolCards() {
		int number = 0;
		for (int i = 0 ; i < hand.size() ; i++) {
			if (hand.get(i).getType() == "wool") {
				number++;
			}
		}
		return number;
	}
	
	public int getNumberOfLumberCards() {
		int number = 0;
		for (int i = 0 ; i < hand.size() ; i++) {
			if (hand.get(i).getType() == "lumber") {
				number++;
			}
		}
		return number;
	}
	
	public int getNumberOfOreCards() {
		int number = 0;
		for (int i = 0 ; i < hand.size() ; i++) {
			if (hand.get(i).getType() == "ore") {
				number++;
			}
		}
		return number;
	}
	
	public int getNumberOfBrickCards() {
		int number = 0;
		for (int i = 0 ; i < hand.size() ; i++) {
			if (hand.get(i).getType() == "brick") {
				number++;
			}
		}
		return number;
	}
	
	public int getNumberOfGrainCards() {
		int number = 0;
		for (int i = 0 ; i < hand.size() ; i++) {
			if (hand.get(i).getType() == "grain") {
				number++;
			}
		}
		return number;
	}
	
	
	

}
