package settlers;

public class ResourceCard implements Card{
	
	private String type;
	private int cardId;
	private String generalType;

	public ResourceCard(String type, int cardId) {
		setType(type);
		setCardId(cardId);
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public int getCardId() {
		return cardId;
	}

	public void setCardId(int cardId) {
		this.cardId = cardId;
	}

	@Override
	public void setGeneralType(String type) {
		this.generalType = type;
	}

	@Override
	public String getGeneralType() {
		return generalType;
	}
	
	

	
}
